import 'package:flutter/material.dart'; // This import is necessary for Material widgets

class RendezVous extends StatefulWidget {
  @override
  _RendezVousState createState() => _RendezVousState();
}

class _RendezVousState extends State<RendezVous> {
  @override
  Widget build(BuildContext context) {
    // ! TO DO
    return Container(); 
  }
}
