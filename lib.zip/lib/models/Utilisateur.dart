class Utilisateur {
  String uid;
  String nom;
  String prenom;
  String role;


    Utilisateur({required this.uid,required this.nom, required this.prenom, required this.role});

}
